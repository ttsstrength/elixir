defmodule Discuss.PageView do
  use Discuss.Web, :view
end
