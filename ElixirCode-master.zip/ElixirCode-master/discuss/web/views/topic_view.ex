defmodule Discuss.TopicView do
  use Discuss.Web, :view
end
