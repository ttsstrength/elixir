defmodule Reddit.LayoutViewTest do
  use Reddit.ConnCase, async: true
end
