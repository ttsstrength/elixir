defmodule Reddit.PageViewTest do
  use Reddit.ConnCase, async: true
end
