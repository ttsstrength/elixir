defmodule Reddit.Repo do
  use Ecto.Repo, otp_app: :reddit
end
