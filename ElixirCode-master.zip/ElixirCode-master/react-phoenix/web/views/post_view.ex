defmodule Reddit.PostView do
  use Reddit.Web, :view
end
