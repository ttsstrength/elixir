defmodule Reddit.LayoutView do
  use Reddit.Web, :view
end
