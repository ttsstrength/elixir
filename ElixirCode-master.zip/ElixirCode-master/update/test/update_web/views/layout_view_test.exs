defmodule UpdateWeb.LayoutViewTest do
  use UpdateWeb.ConnCase, async: true
end
