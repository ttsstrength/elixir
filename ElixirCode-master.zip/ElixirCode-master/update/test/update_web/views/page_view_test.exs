defmodule UpdateWeb.PageViewTest do
  use UpdateWeb.ConnCase, async: true
end
