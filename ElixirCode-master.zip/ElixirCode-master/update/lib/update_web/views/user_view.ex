defmodule UpdateWeb.UserView do
  use UpdateWeb, :view
end
