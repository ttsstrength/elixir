defmodule UpdateWeb.TopicView do
  use UpdateWeb, :view
end
