defmodule UpdateWeb.LayoutView do
  use UpdateWeb, :view
end
