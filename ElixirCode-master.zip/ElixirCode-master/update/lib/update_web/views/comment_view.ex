defmodule UpdateWeb.CommentView do
  use UpdateWeb, :view
end
