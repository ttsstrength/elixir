defmodule UpdateWeb.PageView do
  use UpdateWeb, :view
end
