defmodule IdenticonTest do
  use ExUnit.Case
  doctest Identicon

  test "the truth" do
    assert 1 + 1 == 2
  end
end
